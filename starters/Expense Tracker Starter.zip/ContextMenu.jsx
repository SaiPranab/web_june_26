import React from 'react'

const ContextManu = () => {
  return (
    <div className="context-menu">
      <div>Edit</div>
      <div>Delete</div>
    </div>
  )
}

export default ContextManu