export default function CountriesList() {
  return (
    <div className="countries-container">

      {/* 
        TODO:
        1. Use map() on countriesData
        2. Create one CountryCard for each country
        3. Pass the required data as props
      */}

    </div>
  )
}
