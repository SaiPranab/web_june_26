export default function CountryCard({
  name,
  flag,
  population,
  region,
  capital
}) {
  return (
    <a className="country-card" href="#">

      <div className="flag-container">
        {/* TODO: Display the country flag */}
      </div>

      <div className="card-text">

        {/* TODO: Display country name */}
        <h3 className="card-title"></h3>

        {/* TODO: Display population */}
        <p>
          <b>Population: </b>
        </p>

        {/* TODO: Display region */}
        <p>
          <b>Region: </b>
        </p>

        {/* TODO: Display capital */}
        <p>
          <b>Capital: </b>
        </p>

      </div>
    </a>
  )
}
